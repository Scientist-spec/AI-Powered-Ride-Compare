import React from 'react';
import { SlidersHorizontal, DollarSign, Clock, Star } from 'lucide-react';
import { FilterOptions } from '../types';

interface FilterSidebarProps {
  filters: FilterOptions;
  onFiltersChange: (filters: FilterOptions) => void;
}

const FilterSidebar: React.FC<FilterSidebarProps> = ({ filters, onFiltersChange }) => {
  const providers = ['Uber', 'Ola', 'Rapido', 'InDrive', 'Namma Yatri'];
  const vehicleTypes = ['UberGo', 'Go Sedan', 'UberXL', 'Uber Auto', 'Mini', 'Ola Auto', 'Prime Sedan', 'Prime SUV', 'Bike', 'Auto', 'Economy', 'Comfort'];

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 h-fit sticky top-6">
      <div className="flex items-center space-x-2 mb-6">
        <SlidersHorizontal className="h-5 w-5 text-gray-600" />
        <h3 className="text-lg font-semibold text-gray-900">Filters</h3>
      </div>

      <div className="space-y-6">
        {/* Sort By */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-3">Sort by</label>
          <select
            value={filters.sortBy}
            onChange={(e) => onFiltersChange({ ...filters, sortBy: e.target.value as any })}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="ai-recommended">🤖 AI Recommended</option>
            <option value="fare">💰 Lowest Fare</option>
            <option value="time">⚡ Fastest</option>
            <option value="rating">⭐ Best Rated</option>
          </select>
        </div>

        {/* Max Fare */}
        <div>
          <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 mb-3">
            <DollarSign className="h-4 w-4" />
            <span>Max Fare: ₹{filters.maxFare}</span>
          </label>
          <input
            type="range"
            min="30"
            max="1500"
            step="25"
            value={filters.maxFare}
            onChange={(e) => onFiltersChange({ ...filters, maxFare: parseInt(e.target.value) })}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
          />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>₹30</span>
            <span>₹1500</span>
          </div>
        </div>

        {/* Providers */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-3">Providers</label>
          <div className="space-y-2">
            {providers.map((provider) => (
              <label key={provider} className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={filters.providers.includes(provider)}
                  onChange={(e) => {
                    const newProviders = e.target.checked
                      ? [...filters.providers, provider]
                      : filters.providers.filter(p => p !== provider);
                    onFiltersChange({ ...filters, providers: newProviders });
                  }}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm text-gray-700">{provider}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Vehicle Types */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-3">Vehicle Type</label>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {vehicleTypes.map((type) => (
              <label key={type} className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={filters.vehicleTypes.includes(type)}
                  onChange={(e) => {
                    const newTypes = e.target.checked
                      ? [...filters.vehicleTypes, type]
                      : filters.vehicleTypes.filter(t => t !== type);
                    onFiltersChange({ ...filters, vehicleTypes: newTypes });
                  }}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm text-gray-700">{type}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Service Availability Note */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
          <h6 className="text-sm font-semibold text-blue-900 mb-1">📍 Location-Based Services</h6>
          <p className="text-xs text-blue-700">
            Available services vary by city. Bike services may not be available in all locations.
          </p>
        </div>
      </div>
    </div>
  );
};

export default FilterSidebar;