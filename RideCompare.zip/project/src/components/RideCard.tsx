import React from 'react';
import { Star, Clock, MapPin, Zap, Leaf, TrendingUp, ExternalLink, AlertCircle, Users } from 'lucide-react';
import { RideOption } from '../types';

interface RideCardProps {
  ride: RideOption;
  isRecommended?: boolean;
  onBook: (rideId: string) => void;
  passengers?: number;
}

// Vehicle capacity mapping
const vehicleCapacity = {
  'UberGo': 4,
  'Go Sedan': 4,
  'UberXL': 6,
  'Uber Auto': 3,
  'Mini': 4,
  'Ola Auto': 3,
  'Prime Sedan': 4,
  'Prime SUV': 6,
  'Bike': 1,
  'Auto': 3,
  'Economy': 4,
  'Comfort': 4
};

const RideCard: React.FC<RideCardProps> = ({ ride, isRecommended, onBook, passengers = 1 }) => {
  const getProviderColor = (provider: string) => {
    switch (provider) {
      case 'Uber': return 'from-black to-gray-800';
      case 'Ola': return 'from-green-500 to-green-600';
      case 'Rapido': return 'from-yellow-500 to-orange-500';
      case 'InDrive': return 'from-blue-500 to-blue-600';
      case 'Namma Yatri': return 'from-purple-500 to-purple-600';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const getProviderIcon = (provider: string) => {
    switch (provider) {
      case 'Rapido': return <Leaf className="h-4 w-4" />;
      default: return null;
    }
  };

  const getProviderBookingUrl = (provider: string) => {
    switch (provider) {
      case 'Uber':
        return 'https://m.uber.com/looking';
      case 'Ola':
        return 'https://book.olacabs.com/';
      case 'Rapido':
        return 'https://www.rapido.bike/';
      case 'InDrive':
        return 'https://indrive.com/en/city/';
      case 'Namma Yatri':
        return 'https://nammayatri.in/';
      default:
        return '#';
    }
  };

  const handleBooking = () => {
    const bookingUrl = getProviderBookingUrl(ride.provider);
    
    if (bookingUrl !== '#') {
      // Open the provider's booking website in a new tab
      window.open(bookingUrl, '_blank', 'noopener,noreferrer');
    } else {
      // Fallback for providers without direct booking URLs
      alert(`Please download the ${ride.provider} app to complete your booking.`);
    }
  };

  const capacity = vehicleCapacity[ride.vehicleType as keyof typeof vehicleCapacity] || 4;
  const isCapacityMatch = passengers <= capacity;

  return (
    <div className={`bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 ${isRecommended ? 'ring-2 ring-blue-500' : ''}`}>
      {isRecommended && (
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white text-center py-2 rounded-t-xl">
          <div className="flex items-center justify-center space-x-1">
            <Zap className="h-4 w-4" />
            <span className="text-sm font-medium">AI Recommended for {passengers} passenger{passengers > 1 ? 's' : ''}</span>
          </div>
        </div>
      )}
      
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className={`bg-gradient-to-r ${getProviderColor(ride.provider)} text-white px-3 py-1 rounded-full text-sm font-medium flex items-center space-x-1`}>
              {getProviderIcon(ride.provider)}
              <span>{ride.provider}</span>
            </div>
            <span className="text-gray-600 font-medium">{ride.vehicleType}</span>
          </div>
          
          <div className="flex items-center space-x-1">
            <Star className="h-4 w-4 text-yellow-500 fill-current" />
            <span className="text-gray-700 font-medium">{ride.rating}</span>
          </div>
        </div>

        {/* Passenger Capacity Info */}
        <div className="mb-4">
          <div className={`flex items-center space-x-2 text-sm px-3 py-2 rounded-lg ${isCapacityMatch ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
            <Users className="h-4 w-4" />
            <span>
              {capacity === 1 ? '1 rider only' : `Seats ${capacity} passengers`}
              {!isCapacityMatch && ` (Need ${passengers}, fits ${capacity})`}
            </span>
            {isCapacityMatch ? '✅' : '❌'}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">₹{ride.fare}</div>
            <div className="text-xs text-gray-500 flex items-center justify-center space-x-1">
              <AlertCircle className="h-3 w-3" />
              <span>Estimated fare</span>
            </div>
            {passengers > 1 && (
              <div className="text-xs text-blue-600 mt-1">
                ₹{Math.round(ride.fare / passengers)}/person
              </div>
            )}
            {ride.surge && (
              <div className="flex items-center justify-center space-x-1 text-red-600 text-xs mt-1">
                <TrendingUp className="h-3 w-3" />
                <span>{ride.surge}x surge</span>
              </div>
            )}
            {ride.co2Saved && (
              <div className="flex items-center justify-center space-x-1 text-green-600 text-xs mt-1">
                <Leaf className="h-3 w-3" />
                <span>{ride.co2Saved}kg CO₂ saved</span>
              </div>
            )}
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center space-x-1 text-gray-600">
              <Clock className="h-4 w-4" />
              <span className="font-medium">{ride.estimatedTime}</span>
            </div>
            <div className="text-sm text-gray-500">{ride.distance}</div>
          </div>
        </div>

        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-1 text-green-600">
            <MapPin className="h-4 w-4" />
            <span className="text-sm">Arrives in {ride.arrivalTime}</span>
          </div>
        </div>

        <div className="flex flex-wrap gap-1 mb-4">
          {ride.features.map((feature, index) => (
            <span
              key={index}
              className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full"
            >
              {feature}
            </span>
          ))}
        </div>

        {/* Fare Accuracy Notice */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4">
          <div className="flex items-start space-x-2">
            <AlertCircle className="h-4 w-4 text-yellow-600 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-xs text-yellow-800">
                <strong>Estimated fare:</strong> Actual price may vary by ±₹20-50 due to real-time factors. 
                <span className="block mt-1 font-medium">Check {ride.provider} app for final booking price.</span>
              </p>
            </div>
          </div>
        </div>

        {/* Capacity Warning */}
        {!isCapacityMatch && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
            <div className="flex items-start space-x-2">
              <AlertCircle className="h-4 w-4 text-red-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-xs text-red-800">
                  <strong>Capacity Issue:</strong> This vehicle seats {capacity} passengers, but you need {passengers}. 
                  <span className="block mt-1">Consider booking multiple rides or choose a larger vehicle.</span>
                </p>
              </div>
            </div>
          </div>
        )}

        <button
          onClick={handleBooking}
          disabled={!isCapacityMatch}
          className={`w-full py-3 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105 flex items-center justify-center space-x-2 ${
            !isCapacityMatch
              ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
              : isRecommended
              ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-700 hover:to-purple-700'
              : 'bg-gray-900 text-white hover:bg-gray-800'
          }`}
        >
          <span>{!isCapacityMatch ? 'Insufficient Capacity' : `Book with ${ride.provider}`}</span>
          {isCapacityMatch && <ExternalLink className="h-4 w-4" />}
        </button>
      </div>
    </div>
  );
};

export default RideCard;