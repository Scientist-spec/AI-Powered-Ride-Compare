import React, { useState } from 'react';
import { MapPin, Calendar, Users, Search, Navigation, AlertTriangle } from 'lucide-react';
import { SearchParams } from '../types';

interface SearchFormProps {
  onSearch: (params: SearchParams) => void;
}

const popularLocations = {
  // Major Metro Cities
  mumbai: [
    'Bandra West, Mumbai', 'Andheri East, Mumbai', 'Mumbai Central, Mumbai', 'Bandra Kurla Complex, Mumbai',
    'Colaba, Mumbai', 'Powai, Mumbai', 'Chhatrapati Shivaji International Airport, Mumbai', 'Lower Parel, Mumbai',
    'Worli, Mumbai', 'Juhu, Mumbai', 'Thane, Mumbai', 'Navi Mumbai, Mumbai'
  ],
  delhi: [
    'Connaught Place, Delhi', 'Gurgaon, Delhi NCR', 'Indira Gandhi International Airport, Delhi', 'Karol Bagh, Delhi',
    'Lajpat Nagar, Delhi', 'Rajouri Garden, Delhi', 'Dwarka, Delhi', 'Noida, Delhi NCR',
    'Vasant Kunj, Delhi', 'Khan Market, Delhi', 'Greater Kailash, Delhi', 'Nehru Place, Delhi'
  ],
  bangalore: [
    'Koramangala, Bangalore', 'MG Road, Bangalore', 'Whitefield, Bangalore', 'Electronic City, Bangalore',
    'Indiranagar, Bangalore', 'Jayanagar, Bangalore', 'BTM Layout, Bangalore', 'Kempegowda International Airport, Bangalore',
    'Marathahalli, Bangalore', 'HSR Layout, Bangalore', 'Silk Board, Bangalore', 'Ulsoor, Bangalore'
  ],
  chennai: [
    'T Nagar, Chennai', 'Chennai International Airport, Chennai', 'Adyar, Chennai', 'Egmore, Chennai',
    'Velachery, Chennai', 'Anna Nagar, Chennai', 'OMR, Chennai', 'Guindy, Chennai',
    'Mylapore, Chennai', 'Nungambakkam, Chennai', 'Porur, Chennai', 'Tambaram, Chennai'
  ],
  hyderabad: [
    'Hitech City, Hyderabad', 'Secunderabad, Hyderabad', 'Gachibowli, Hyderabad', 'Rajiv Gandhi International Airport, Hyderabad',
    'Jubilee Hills, Hyderabad', 'Begumpet, Hyderabad', 'Kondapur, Hyderabad', 'Charminar, Hyderabad',
    'Banjara Hills, Hyderabad', 'Madhapur, Hyderabad', 'Kukatpally, Hyderabad', 'Ameerpet, Hyderabad'
  ],
  pune: [
    'Koregaon Park, Pune', 'Hinjewadi, Pune', 'Pune Airport, Pune', 'FC Road, Pune',
    'Wakad, Pune', 'Camp, Pune', 'Baner, Pune', 'Katraj, Pune',
    'Kothrud, Pune', 'Viman Nagar, Pune', 'Aundh, Pune', 'Hadapsar, Pune'
  ],
  kolkata: [
    'Salt Lake, Kolkata', 'Netaji Subhash Chandra Bose International Airport, Kolkata', 'Park Street, Kolkata', 'New Town, Kolkata',
    'Howrah, Kolkata', 'Esplanade, Kolkata', 'Ballygunge, Kolkata', 'Dum Dum, Kolkata',
    'Sector V, Kolkata', 'Gariahat, Kolkata', 'Jadavpur, Kolkata', 'Sealdah, Kolkata'
  ],
  // Tier 2 Cities
  ahmedabad: [
    'SG Highway, Ahmedabad', 'Sardar Vallabhbhai Patel International Airport, Ahmedabad', 'Vastrapur, Ahmedabad', 'Maninagar, Ahmedabad',
    'Bopal, Ahmedabad', 'CG Road, Ahmedabad', 'Satellite, Ahmedabad', 'Navrangpura, Ahmedabad'
  ],
  jaipur: [
    'Jaipur International Airport, Jaipur', 'Pink City, Jaipur', 'Malviya Nagar, Jaipur', 'Bapu Nagar, Jaipur',
    'Mansarovar, Jaipur', 'Amer, Jaipur', 'C Scheme, Jaipur', 'Vaishali Nagar, Jaipur'
  ],
  kochi: [
    'Cochin International Airport, Kochi', 'Marine Drive, Kochi', 'Kakkanad, Kochi', 'Fort Cochin, Kochi',
    'Edapally, Kochi', 'MG Road, Kochi', 'Ernakulam, Kochi', 'Vyttila, Kochi'
  ],
  chandigarh: [
    'Sector 17, Chandigarh', 'Chandigarh Airport, Chandigarh', 'Sector 22, Chandigarh', 'Sector 35, Chandigarh',
    'Mohali, Chandigarh', 'Panchkula, Chandigarh', 'Sector 43, Chandigarh', 'Elante Mall, Chandigarh'
  ],
  lucknow: [
    'Chaudhary Charan Singh International Airport, Lucknow', 'Hazratganj, Lucknow', 'Gomti Nagar, Lucknow', 'Aminabad, Lucknow',
    'Alambagh, Lucknow', 'Charbagh, Lucknow', 'Indira Nagar, Lucknow', 'Mahanagar, Lucknow'
  ],
  indore: [
    'Devi Ahilya Bai Holkar Airport, Indore', 'Rajwada, Indore', 'Vijay Nagar, Indore', 'Bhawarkua, Indore',
    'Sapna Sangeeta, Indore', 'Treasure Island, Indore', 'Palasia, Indore', 'Rau, Indore'
  ],
  bhubaneswar: [
    'Biju Patnaik International Airport, Bhubaneswar', 'Master Canteen, Bhubaneswar', 'Patia, Bhubaneswar', 'Khandagiri, Bhubaneswar',
    'Jaydev Vihar, Bhubaneswar', 'Sahid Nagar, Bhubaneswar', 'Nayapalli, Bhubaneswar', 'Unit 4, Bhubaneswar'
  ],
  coimbatore: [
    'Coimbatore International Airport, Coimbatore', 'Gandhipuram, Coimbatore', 'Peelamedu, Coimbatore', 'RS Puram, Coimbatore',
    'Saravanampatti, Coimbatore', 'Ukkadam, Coimbatore', 'Race Course, Coimbatore', 'Singanallur, Coimbatore'
  ],
  visakhapatnam: [
    'Visakhapatnam Airport, Visakhapatnam', 'RK Beach, Visakhapatnam', 'Madhurawada, Visakhapatnam', 'Dwaraka Nagar, Visakhapatnam',
    'MVP Colony, Visakhapatnam', 'Gajuwaka, Visakhapatnam', 'Rushikonda, Visakhapatnam', 'Waltair, Visakhapatnam'
  ],
  guwahati: [
    'Lokpriya Gopinath Bordoloi International Airport, Guwahati', 'Fancy Bazaar, Guwahati', 'Six Mile, Guwahati', 'Paltan Bazaar, Guwahati',
    'Zoo Road, Guwahati', 'Dispur, Guwahati', 'Ulubari, Guwahati', 'Ganeshguri, Guwahati'
  ]
};

const SearchForm: React.FC<SearchFormProps> = ({ onSearch }) => {
  const [searchParams, setSearchParams] = useState<SearchParams>({
    from: '',
    to: '',
    dateTime: new Date().toISOString().slice(0, 16),
    passengers: 1,
  });

  const [showFromSuggestions, setShowFromSuggestions] = useState(false);
  const [showToSuggestions, setShowToSuggestions] = useState(false);

  const getAllLocations = () => {
    return Object.values(popularLocations).flat();
  };

  const getFilteredSuggestions = (input: string) => {
    if (!input) return getAllLocations().slice(0, 12);
    return getAllLocations().filter(location => 
      location.toLowerCase().includes(input.toLowerCase())
    ).slice(0, 8);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchParams.from.trim() || !searchParams.to.trim()) {
      alert('Please enter both pickup and destination locations');
      return;
    }
    onSearch(searchParams);
  };

  const swapLocations = () => {
    setSearchParams(prev => ({
      ...prev,
      from: prev.to,
      to: prev.from
    }));
  };

  return (
    <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-blue-800 py-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-4xl font-bold text-white mb-3">
            Compare Rides Across All India
          </h2>
          <p className="text-blue-100 text-lg">
            From Mumbai to Chennai, Delhi to Bangalore - Get the best fares across 15+ major cities
          </p>
        </div>

        {/* Important Disclaimer */}
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-8 rounded-r-lg">
          <div className="flex items-start">
            <AlertTriangle className="h-5 w-5 text-yellow-400 mt-0.5 mr-3 flex-shrink-0" />
            <div>
              <h4 className="text-sm font-semibold text-yellow-800 mb-1">⚠️ Fare Estimation Disclaimer</h4>
              <p className="text-sm text-yellow-700 leading-relaxed">
                <strong>These are estimated fares</strong> based on 2024 pricing structures and may vary from actual platform prices by ±₹20-50 due to real-time factors like surge pricing, traffic, and route optimization. 
                <strong className="block mt-1">Always check the official app for final booking prices.</strong>
              </p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-3xl shadow-2xl p-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-8">
            {/* From Location */}
            <div className="lg:col-span-4 relative">
              <label className="block text-sm font-semibold text-gray-700 mb-3">Pickup Location</label>
              <div className="relative">
                <MapPin className="absolute left-4 top-4 h-5 w-5 text-green-500 z-10" />
                <input
                  type="text"
                  value={searchParams.from}
                  onChange={(e) => {
                    setSearchParams({ ...searchParams, from: e.target.value });
                    setShowFromSuggestions(true);
                  }}
                  onFocus={() => setShowFromSuggestions(true)}
                  onBlur={() => setTimeout(() => setShowFromSuggestions(false), 200)}
                  className="w-full pl-12 pr-4 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200"
                  placeholder="Enter any city in India"
                  required
                />
                
                {showFromSuggestions && (
                  <div className="absolute top-full left-0 right-0 bg-white border border-gray-200 rounded-xl shadow-lg z-20 mt-1 max-h-80 overflow-y-auto">
                    <div className="p-3 bg-gray-50 border-b">
                      <h4 className="text-sm font-semibold text-gray-700">Popular Locations Across India</h4>
                    </div>
                    {getFilteredSuggestions(searchParams.from).map((location, index) => (
                      <div
                        key={index}
                        className="px-4 py-3 hover:bg-gray-50 cursor-pointer border-b border-gray-100 last:border-b-0"
                        onClick={() => {
                          setSearchParams({ ...searchParams, from: location });
                          setShowFromSuggestions(false);
                        }}
                      >
                        <div className="flex items-center space-x-3">
                          <MapPin className="h-4 w-4 text-gray-400" />
                          <div>
                            <span className="text-gray-700 font-medium">{location.split(',')[0]}</span>
                            <span className="text-gray-500 text-sm ml-1">{location.split(',')[1]}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Swap Button */}
            <div className="lg:col-span-1 flex items-end justify-center pb-4">
              <button
                type="button"
                onClick={swapLocations}
                className="p-3 bg-gray-100 hover:bg-gray-200 rounded-full transition-all duration-200 transform hover:scale-110"
              >
                <Navigation className="h-5 w-5 text-gray-600 transform rotate-90" />
              </button>
            </div>

            {/* To Location */}
            <div className="lg:col-span-4 relative">
              <label className="block text-sm font-semibold text-gray-700 mb-3">Destination</label>
              <div className="relative">
                <MapPin className="absolute left-4 top-4 h-5 w-5 text-red-500 z-10" />
                <input
                  type="text"
                  value={searchParams.to}
                  onChange={(e) => {
                    setSearchParams({ ...searchParams, to: e.target.value });
                    setShowToSuggestions(true);
                  }}
                  onFocus={() => setShowToSuggestions(true)}
                  onBlur={() => setTimeout(() => setShowToSuggestions(false), 200)}
                  className="w-full pl-12 pr-4 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200"
                  placeholder="Enter destination city"
                  required
                />
                
                {showToSuggestions && (
                  <div className="absolute top-full left-0 right-0 bg-white border border-gray-200 rounded-xl shadow-lg z-20 mt-1 max-h-80 overflow-y-auto">
                    <div className="p-3 bg-gray-50 border-b">
                      <h4 className="text-sm font-semibold text-gray-700">Popular Destinations</h4>
                    </div>
                    {getFilteredSuggestions(searchParams.to).map((location, index) => (
                      <div
                        key={index}
                        className="px-4 py-3 hover:bg-gray-50 cursor-pointer border-b border-gray-100 last:border-b-0"
                        onClick={() => {
                          setSearchParams({ ...searchParams, to: location });
                          setShowToSuggestions(false);
                        }}
                      >
                        <div className="flex items-center space-x-3">
                          <MapPin className="h-4 w-4 text-gray-400" />
                          <div>
                            <span className="text-gray-700 font-medium">{location.split(',')[0]}</span>
                            <span className="text-gray-500 text-sm ml-1">{location.split(',')[1]}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Date & Time */}
            <div className="lg:col-span-2">
              <label className="block text-sm font-semibold text-gray-700 mb-3">Date & Time</label>
              <div className="relative">
                <Calendar className="absolute left-4 top-4 h-5 w-5 text-blue-500 z-10" />
                <input
                  type="datetime-local"
                  value={searchParams.dateTime}
                  onChange={(e) => setSearchParams({ ...searchParams, dateTime: e.target.value })}
                  className="w-full pl-12 pr-4 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200"
                />
              </div>
            </div>

            {/* Passengers */}
            <div className="lg:col-span-1">
              <label className="block text-sm font-semibold text-gray-700 mb-3">Passengers</label>
              <div className="relative">
                <Users className="absolute left-4 top-4 h-5 w-5 text-purple-500 z-10" />
                <select
                  value={searchParams.passengers}
                  onChange={(e) => setSearchParams({ ...searchParams, passengers: parseInt(e.target.value) })}
                  className="w-full pl-12 pr-4 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200"
                >
                  <option value={1}>1</option>
                  <option value={2}>2</option>
                  <option value={3}>3</option>
                  <option value={4}>4</option>
                  <option value={5}>5</option>
                  <option value={6}>6</option>
                </select>
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-5 px-8 rounded-xl font-bold text-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-300 flex items-center justify-center space-x-3 transform hover:scale-105 shadow-lg"
          >
            <Search className="h-6 w-6" />
            <span>Compare Rides Across India</span>
          </button>

          {/* Popular Routes */}
          <div className="mt-8 pt-6 border-t border-gray-200">
            <h4 className="text-sm font-semibold text-gray-700 mb-4">Popular Routes Across India</h4>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              {[
                { from: 'Koramangala, Bangalore', to: 'MG Road, Bangalore', label: 'Bangalore Local' },
                { from: 'Bandra West, Mumbai', to: 'Andheri East, Mumbai', label: 'Mumbai Metro' },
                { from: 'Connaught Place, Delhi', to: 'Gurgaon, Delhi NCR', label: 'Delhi NCR' },
                { from: 'T Nagar, Chennai', to: 'Chennai International Airport, Chennai', label: 'Chennai Airport' },
              ].map((route, index) => (
                <button
                  key={index}
                  type="button"
                  onClick={() => setSearchParams({ 
                    ...searchParams, 
                    from: route.from, 
                    to: route.to 
                  })}
                  className="text-left p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors duration-200"
                >
                  <div className="text-xs text-blue-600 font-medium mb-1">{route.label}</div>
                  <div className="text-sm text-gray-600">
                    {route.from.split(',')[0]} → {route.to.split(',')[0]}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* City Coverage */}
          <div className="mt-6 pt-4 border-t border-gray-100">
            <h5 className="text-xs font-semibold text-gray-600 mb-3">Available in 15+ Major Cities</h5>
            <div className="flex flex-wrap gap-2">
              {['Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Hyderabad', 'Pune', 'Kolkata', 'Ahmedabad', 'Jaipur', 'Kochi', 'Chandigarh', 'Lucknow', 'Indore', 'Bhubaneswar', 'Coimbatore'].map((city) => (
                <span key={city} className="px-2 py-1 bg-blue-50 text-blue-700 text-xs rounded-full">
                  {city}
                </span>
              ))}
            </div>
          </div>

          {/* Accuracy Note */}
          <div className="mt-6 pt-4 border-t border-gray-100">
            <div className="bg-blue-50 rounded-lg p-4">
              <h6 className="text-sm font-semibold text-blue-900 mb-2">💡 About Our Fare Estimates</h6>
              <ul className="text-xs text-blue-800 space-y-1">
                <li>• Based on latest 2024 platform pricing structures</li>
                <li>• Includes base fare, per-km charges, and booking fees</li>
                <li>• Accounts for city-specific rates and traffic patterns</li>
                <li>• Real-time surge pricing and promotions may affect final cost</li>
                <li>• <strong>Always verify final price on the respective platform before booking</strong></li>
              </ul>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SearchForm;