import React from 'react';
import { Brain, TrendingDown, Zap, Award, DollarSign, MapPin, AlertTriangle, Users } from 'lucide-react';
import { RideOption } from '../types';

interface AIInsightsProps {
  rides: RideOption[];
  recommendation?: any;
  passengers?: number;
}

const AIInsights: React.FC<AIInsightsProps> = ({ rides, recommendation, passengers = 1 }) => {
  if (!recommendation) return null;

  const cheapestRide = rides.find(r => r.id === recommendation.cheapest);
  const fastestRide = rides.find(r => r.id === recommendation.fastest);
  const bestRatedRide = rides.find(r => r.id === recommendation.bestRated);

  const insights = [
    {
      icon: <DollarSign className="h-5 w-5 text-green-500" />,
      title: 'Most Economical',
      value: `₹${cheapestRide?.fare} with ${cheapestRide?.provider}`,
      description: `Save ₹${Math.max(...rides.map(r => r.fare)) - (cheapestRide?.fare || 0)} compared to most expensive`,
      color: 'bg-green-50 border-green-200',
    },
    {
      icon: <Zap className="h-5 w-5 text-yellow-500" />,
      title: 'Fastest Route',
      value: `${fastestRide?.estimatedTime} with ${fastestRide?.provider}`,
      description: `${fastestRide?.vehicleType} - Best for time-sensitive trips`,
      color: 'bg-yellow-50 border-yellow-200',
    },
    {
      icon: <Award className="h-5 w-5 text-purple-500" />,
      title: 'Top Rated',
      value: `${bestRatedRide?.rating}⭐ ${bestRatedRide?.provider}`,
      description: `${bestRatedRide?.vehicleType} - Highest customer satisfaction`,
      color: 'bg-purple-50 border-purple-200',
    },
  ];

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
      <div className="flex items-center space-x-3 mb-8">
        <div className="p-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg">
          <Brain className="h-6 w-6 text-white" />
        </div>
        <div>
          <h3 className="text-2xl font-bold text-gray-900">AI-Powered Insights</h3>
          <p className="text-gray-600 text-sm flex items-center space-x-2">
            <Users className="h-4 w-4" />
            <span>Smart recommendations for {passengers} passenger{passengers > 1 ? 's' : ''}</span>
          </p>
        </div>
      </div>

      {/* Important Disclaimer */}
      <div className="bg-amber-50 border-l-4 border-amber-400 p-4 mb-8 rounded-r-lg">
        <div className="flex items-start">
          <AlertTriangle className="h-5 w-5 text-amber-400 mt-0.5 mr-3 flex-shrink-0" />
          <div>
            <h4 className="text-sm font-semibold text-amber-800 mb-1">⚠️ Fare Estimation Notice</h4>
            <p className="text-sm text-amber-700">
              These are <strong>estimated fares</strong> based on 2024 pricing data. Actual costs may vary by ±₹20-50 due to surge pricing, traffic conditions, and route optimization. 
              <strong className="block mt-1">Always verify the final price on the respective platform before booking.</strong>
            </p>
          </div>
        </div>
      </div>

      {/* Passenger-Specific Recommendation */}
      <div className="bg-gradient-to-r from-blue-50 via-purple-50 to-blue-50 border-2 border-blue-200 rounded-xl p-6 mb-8">
        <div className="flex items-start space-x-3">
          <div className="p-2 bg-blue-100 rounded-lg">
            <Users className="h-5 w-5 text-blue-600" />
          </div>
          <div>
            <h4 className="font-bold text-gray-900 mb-2">
              🎯 Smart Recommendation for {passengers} Passenger{passengers > 1 ? 's' : ''}
            </h4>
            <p className="text-gray-700 leading-relaxed">{recommendation.reasoning}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {insights.map((insight, index) => (
          <div key={index} className={`border-2 rounded-xl p-6 transition-all duration-200 hover:shadow-lg ${insight.color}`}>
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-white rounded-lg shadow-sm">
                {insight.icon}
              </div>
              <h5 className="font-bold text-gray-900">{insight.title}</h5>
            </div>
            <div className="font-bold text-gray-900 mb-2 text-lg">{insight.value}</div>
            <div className="text-sm text-gray-600 leading-relaxed">{insight.description}</div>
            <div className="text-xs text-gray-500 mt-2 italic">*Estimated pricing</div>
          </div>
        ))}
      </div>

      {/* Passenger-Specific Insights */}
      <div className="mt-8 pt-6 border-t border-gray-200">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gray-50 rounded-xl p-4">
            <h6 className="font-semibold text-gray-900 mb-2 flex items-center space-x-2">
              <Users className="h-4 w-4" />
              <span>Passenger Tip</span>
            </h6>
            <p className="text-sm text-gray-600">
              {passengers === 1 
                ? "For solo travel, bikes and autos are often 40-60% cheaper than cars and faster in traffic!"
                : passengers <= 4 
                ? `For ${passengers} passengers, sedans offer the best comfort-to-cost ratio. Autos work great for up to 3 people.`
                : `For ${passengers} passengers, XL/SUV options are more economical than booking multiple rides and keep everyone together.`
              }
            </p>
          </div>
          <div className="bg-gray-50 rounded-xl p-4">
            <h6 className="font-semibold text-gray-900 mb-2">⏰ Best Time</h6>
            <p className="text-sm text-gray-600">
              {new Date().getHours() >= 8 && new Date().getHours() <= 10 || new Date().getHours() >= 17 && new Date().getHours() <= 20
                ? "Peak hours detected - expect surge pricing and longer wait times."
                : "Off-peak timing - enjoy better prices and faster pickups!"
              }
            </p>
          </div>
        </div>
      </div>

      {/* Accuracy Information */}
      <div className="mt-6 pt-4 border-t border-gray-100">
        <div className="bg-blue-50 rounded-lg p-4">
          <h6 className="text-sm font-semibold text-blue-900 mb-2">📊 About Our Estimates</h6>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-blue-800">
            <div>
              <strong>What's Included:</strong>
              <ul className="mt-1 space-y-1">
                <li>• Base fare + per-km charges</li>
                <li>• Platform booking fees</li>
                <li>• City-specific pricing</li>
                <li>• Passenger capacity matching</li>
              </ul>
            </div>
            <div>
              <strong>What May Vary:</strong>
              <ul className="mt-1 space-y-1">
                <li>• Real-time surge pricing</li>
                <li>• Route optimization</li>
                <li>• Promotional discounts</li>
                <li>• Peak hour adjustments</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIInsights;