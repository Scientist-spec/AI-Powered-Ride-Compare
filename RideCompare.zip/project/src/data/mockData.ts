import { RideOption } from '../types';

export const mockRideOptions: RideOption[] = [
  {
    id: '1',
    provider: 'Uber',
    vehicleType: 'UberGo',
    fare: 180,
    estimatedTime: '12-15 min',
    distance: '8.2 km',
    rating: 4.8,
    features: ['AC', 'GPS Tracking', '24/7 Support'],
    arrivalTime: '3 min',
  },
  {
    id: '2',
    provider: 'Ola',
    vehicleType: 'Mini',
    fare: 165,
    estimatedTime: '15-18 min',
    distance: '8.2 km',
    rating: 4.6,
    features: ['AC', 'GPS Tracking', 'Safety Features'],
    arrivalTime: '5 min',
  },
  {
    id: '3',
    provider: 'Rapido',
    vehicleType: 'Bike',
    fare: 85,
    estimatedTime: '10-12 min',
    distance: '8.2 km',
    rating: 4.4,
    features: ['Fastest Route', 'Affordable', 'Eco-friendly'],
    arrivalTime: '2 min',
    co2Saved: 2.5,
  },
  {
    id: '4',
    provider: 'InDrive',
    vehicleType: 'Economy',
    fare: 150,
    estimatedTime: '14-16 min',
    distance: '8.2 km',
    rating: 4.5,
    features: ['Negotiate Fare', 'Choose Driver', 'Fixed Price'],
    arrivalTime: '4 min',
  },
  {
    id: '5',
    provider: 'Uber',
    vehicleType: 'UberX',
    fare: 220,
    estimatedTime: '12-15 min',
    distance: '8.2 km',
    rating: 4.9,
    surge: 1.2,
    features: ['Premium', 'AC', 'Spacious', 'Top Rated'],
    arrivalTime: '3 min',
  },
  {
    id: '6',
    provider: 'Ola',
    vehicleType: 'Prime',
    fare: 280,
    estimatedTime: '12-14 min',
    distance: '8.2 km',
    rating: 4.7,
    features: ['Premium', 'AC', 'Leather Seats', 'Wi-Fi'],
    arrivalTime: '6 min',
  },
];

export const aiRecommendation = {
  bestOverall: '1', // Uber Go
  cheapest: '3', // Rapido
  fastest: '3', // Rapido
  bestRated: '5', // UberX
  reasoning: 'Based on your preferences for balanced fare and time, UberGo offers the best combination of reliability, cost-effectiveness, and arrival time.',
};