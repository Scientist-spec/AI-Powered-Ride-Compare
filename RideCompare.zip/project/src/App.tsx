import React, { useState, useMemo } from 'react';
import Header from './components/Header';
import SearchForm from './components/SearchForm';
import FilterSidebar from './components/FilterSidebar';
import RideCard from './components/RideCard';
import AIInsights from './components/AIInsights';
import { SearchParams, FilterOptions, RideOption } from './types';
import { generateLocationBasedRides, getAIRecommendation, detectCity } from './utils/locationService';

function App() {
  const [searchResults, setSearchResults] = useState<RideOption[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [currentSearch, setCurrentSearch] = useState<SearchParams | null>(null);
  const [aiRecommendation, setAiRecommendation] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [filters, setFilters] = useState<FilterOptions>({
    maxFare: 1500,
    maxTime: 60,
    providers: ['Uber', 'Ola', 'Rapido', 'InDrive', 'Namma Yatri'],
    vehicleTypes: ['UberGo', 'Go Sedan', 'UberXL', 'Uber Auto', 'Mini', 'Ola Auto', 'Prime Sedan', 'Prime SUV', 'Bike', 'Auto', 'Economy', 'Comfort'],
    sortBy: 'ai-recommended',
  });

  const handleSearch = (params: SearchParams) => {
    setIsLoading(true);
    setCurrentSearch(params);
    
    // Simulate API call with realistic delay
    setTimeout(() => {
      const rides = generateLocationBasedRides(params.from, params.to, params.passengers);
      const recommendation = getAIRecommendation(rides, params.from, params.to, params.passengers);
      
      setSearchResults(rides);
      setAiRecommendation(recommendation);
      setShowResults(true);
      setIsLoading(false);
    }, 1500);
  };

  const filteredAndSortedRides = useMemo(() => {
    let filtered = searchResults.filter(ride => 
      ride.fare <= filters.maxFare &&
      filters.providers.includes(ride.provider) &&
      (filters.vehicleTypes.some(type => 
        ride.vehicleType.toLowerCase().includes(type.toLowerCase()) ||
        type.toLowerCase().includes(ride.vehicleType.toLowerCase())
      ))
    );

    // Sort based on selected criteria
    switch (filters.sortBy) {
      case 'fare':
        filtered.sort((a, b) => a.fare - b.fare);
        break;
      case 'time':
        filtered.sort((a, b) => {
          const aTime = parseInt(a.estimatedTime.split('-')[0]);
          const bTime = parseInt(b.estimatedTime.split('-')[0]);
          return aTime - bTime;
        });
        break;
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating);
        break;
      case 'ai-recommended':
        // Put AI recommended rides first
        if (aiRecommendation) {
          filtered.sort((a, b) => {
            if (a.id === aiRecommendation.bestOverall) return -1;
            if (b.id === aiRecommendation.bestOverall) return 1;
            return 0;
          });
        }
        break;
    }

    return filtered;
  }, [searchResults, filters, aiRecommendation]);

  const handleBookRide = (rideId: string) => {
    // This function is no longer needed as booking is handled directly in RideCard
    // But keeping it for compatibility
    console.log(`Booking ride ${rideId}`);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <SearchForm onSearch={handleSearch} />

      {isLoading && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mb-4"></div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Finding the best rides across India...</h3>
            <p className="text-gray-600">Comparing fares from all major platforms</p>
          </div>
        </div>
      )}

      {showResults && !isLoading && currentSearch && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <AIInsights rides={searchResults} recommendation={aiRecommendation} passengers={currentSearch.passengers} />
          
          <div className="flex flex-col lg:flex-row gap-8">
            <div className="lg:w-1/4">
              <FilterSidebar
                filters={filters}
                onFiltersChange={setFilters}
              />
            </div>
            
            <div className="lg:w-3/4">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">
                  Available Rides ({filteredAndSortedRides.length})
                </h2>
                <div className="text-sm text-gray-600 bg-white px-4 py-2 rounded-lg shadow">
                  <div className="font-medium">
                    {currentSearch.from.split(',')[0]} → {currentSearch.to.split(',')[0]}
                  </div>
                  <div className="text-xs text-gray-500">
                    {searchResults[0]?.distance} • {detectCity(currentSearch.from)} • {currentSearch.passengers} passenger{currentSearch.passengers > 1 ? 's' : ''} • {new Date(currentSearch.dateTime).toLocaleDateString()}
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredAndSortedRides.map((ride) => (
                  <RideCard
                    key={ride.id}
                    ride={ride}
                    isRecommended={aiRecommendation && ride.id === aiRecommendation.bestOverall}
                    onBook={handleBookRide}
                    passengers={currentSearch.passengers}
                  />
                ))}
              </div>
              
              {filteredAndSortedRides.length === 0 && (
                <div className="text-center py-12 bg-white rounded-xl shadow-lg">
                  <div className="text-gray-500 text-lg mb-2">No rides match your current filters</div>
                  <p className="text-gray-400">Try adjusting your filter criteria or search different locations</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {!showResults && !isLoading && (
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold text-gray-900 mb-6">
              How RideCompare Works Across India
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                  <span className="text-3xl">🗺️</span>
                </div>
                <h4 className="font-bold text-gray-900 mb-3 text-lg">Pan-India Coverage</h4>
                <p className="text-gray-600">Search rides across 15+ major cities from Mumbai to Chennai, Delhi to Bangalore</p>
              </div>
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                  <span className="text-3xl">🤖</span>
                </div>
                <h4 className="font-bold text-gray-900 mb-3 text-lg">Smart Passenger-Based AI</h4>
                <p className="text-gray-600">AI recommends rides based on your group size - from solo bikes to family SUVs</p>
              </div>
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                  <span className="text-3xl">💰</span>
                </div>
                <h4 className="font-bold text-gray-900 mb-3 text-lg">Best Local Rates</h4>
                <p className="text-gray-600">Compare fares adjusted for local economics and get the best deals in every city</p>
              </div>
            </div>
          </div>

          {/* Updated Service Availability Info */}
          <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
            <h4 className="text-xl font-bold text-gray-900 mb-6 text-center">Smart Recommendations by Passenger Count</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-gradient-to-r from-green-50 to-green-100 border-2 border-green-200 p-6 rounded-xl">
                <h5 className="font-bold mb-3 text-green-800">👤 Solo Travel (1 Person)</h5>
                <ul className="text-sm space-y-2 text-green-700">
                  <li>🏍️ <strong>Bikes:</strong> Fastest & cheapest for short trips</li>
                  <li>🛺 <strong>Auto:</strong> Good balance of speed & comfort</li>
                  <li>🚗 <strong>Cars:</strong> Best for longer distances</li>
                  <li className="text-xs italic">💡 Save 40-60% with bikes/autos!</li>
                </ul>
              </div>
              <div className="bg-gradient-to-r from-blue-50 to-blue-100 border-2 border-blue-200 p-6 rounded-xl">
                <h5 className="font-bold mb-3 text-blue-800">👥 Small Groups (2-4 People)</h5>
                <ul className="text-sm space-y-2 text-blue-700">
                  <li>🚗 <strong>Sedans:</strong> Comfortable for everyone</li>
                  <li>🛺 <strong>Auto:</strong> Economical for up to 3 people</li>
                  <li>❄️ <strong>AC Cars:</strong> Best for longer journeys</li>
                  <li className="text-xs italic">💡 Perfect for family trips!</li>
                </ul>
              </div>
              <div className="bg-gradient-to-r from-purple-50 to-purple-100 border-2 border-purple-200 p-6 rounded-xl">
                <h5 className="font-bold mb-3 text-purple-800">👨‍👩‍👧‍👦 Large Groups (5+ People)</h5>
                <ul className="text-sm space-y-2 text-purple-700">
                  <li>🚙 <strong>SUVs:</strong> 6-7 seater capacity</li>
                  <li>🚐 <strong>XL Options:</strong> Extra space & comfort</li>
                  <li>💰 <strong>Cost Effective:</strong> Cheaper than multiple rides</li>
                  <li className="text-xs italic">💡 Everyone travels together!</li>
                </ul>
              </div>
            </div>
          </div>

          {/* City Coverage Grid */}
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <h4 className="text-xl font-bold text-gray-900 mb-6 text-center">Available Across Major Indian Cities</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
              {[
                { city: 'Mumbai', highlight: 'Financial Capital', color: 'from-blue-50 to-blue-100', note: 'No Bikes' },
                { city: 'Delhi NCR', highlight: 'National Capital', color: 'from-red-50 to-red-100', note: 'Full Services' },
                { city: 'Bangalore', highlight: 'Silicon Valley', color: 'from-green-50 to-green-100', note: 'Namma Yatri' },
                { city: 'Chennai', highlight: 'Detroit of India', color: 'from-yellow-50 to-yellow-100', note: 'Full Services' },
                { city: 'Hyderabad', highlight: 'Cyberabad', color: 'from-purple-50 to-purple-100', note: 'Full Services' },
                { city: 'Pune', highlight: 'Oxford of East', color: 'from-pink-50 to-pink-100', note: 'Full Services' },
                { city: 'Kolkata', highlight: 'Cultural Capital', color: 'from-indigo-50 to-indigo-100', note: 'Limited Bikes' },
                { city: 'Ahmedabad', highlight: 'Manchester of India', color: 'from-orange-50 to-orange-100', note: 'Full Services' },
                { city: 'Jaipur', highlight: 'Pink City', color: 'from-rose-50 to-rose-100', note: 'Full Services' },
                { city: 'Kochi', highlight: 'Queen of Arabian Sea', color: 'from-teal-50 to-teal-100', note: 'Full Services' },
                { city: 'Chandigarh', highlight: 'City Beautiful', color: 'from-cyan-50 to-cyan-100', note: 'Full Services' },
                { city: 'Lucknow', highlight: 'City of Nawabs', color: 'from-amber-50 to-amber-100', note: 'Full Services' },
                { city: 'Indore', highlight: 'Commercial Capital of MP', color: 'from-lime-50 to-lime-100', note: 'Full Services' },
                { city: 'Bhubaneswar', highlight: 'Temple City', color: 'from-emerald-50 to-emerald-100', note: 'Full Services' },
                { city: 'Coimbatore', highlight: 'Manchester of South', color: 'from-violet-50 to-violet-100', note: 'Full Services' },
              ].map((location, index) => (
                <div key={index} className={`text-center p-4 bg-gradient-to-r ${location.color} rounded-xl hover:shadow-md transition-shadow duration-200`}>
                  <h5 className="font-semibold text-gray-900 mb-1">{location.city}</h5>
                  <p className="text-xs text-gray-600 mb-1">{location.highlight}</p>
                  <span className="text-xs bg-white px-2 py-1 rounded-full text-gray-700">{location.note}</span>
                </div>
              ))}
            </div>
            
            <div className="mt-8 text-center">
              <p className="text-gray-600 text-sm">
                🚀 <strong>More cities coming soon!</strong> We're expanding to cover every major destination across India.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;