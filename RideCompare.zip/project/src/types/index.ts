export interface RideOption {
  id: string;
  provider: 'Uber' | 'Ola' | 'Rapido' | 'InDrive' | 'Namma Yatri';
  vehicleType: string;
  fare: number;
  estimatedTime: string;
  distance: string;
  rating: number;
  surge?: number;
  features: string[];
  arrivalTime: string;
  co2Saved?: number;
}

export interface SearchParams {
  from: string;
  to: string;
  dateTime: string;
  passengers: number;
}

export interface FilterOptions {
  maxFare: number;
  maxTime: number;
  providers: string[];
  vehicleTypes: string[];
  sortBy: 'fare' | 'time' | 'rating' | 'ai-recommended';
}

export interface LocationData {
  from: string;
  to: string;
  distance: string;
  estimatedDuration: string;
}